package com.csci340.mazjoeproject;

import java.util.Scanner;
import java.util.concurrent.Semaphore;



public class Main {
	public static Semaphore sem = new Semaphore(1);
	static Scanner input = new Scanner(System.in);
	
	
	public static int whoseTurn;
	
	public static void main(String[] args) {
		
		whoseTurn=0;
	
		System.out.println("Enter name!");
		
		
		Adventurer.health=10;
		Adventurer.name = input.nextLine();
		System.out.println("Behold! The mightiest warrior of his era! His name be mighty, and his name be " + Adventurer.name + "!");
		
		HydraHead.headCount = 0;
		
		HydraHead[] hydra= new HydraHead[40];
		
		for(int i = 0; i < hydra.length; ++i){
			hydra[i] = new HydraHead(i);
		}
		
		for (int i = 1; i < 4; ++i){
			try {
				sem.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			hydra[HydraHead.headCount].start();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				sem.release();
		}
		
		
		while(Adventurer.health>0 && HydraHead.livingHeads>0){
			System.out.printf("%d heads still alive!\n", HydraHead.livingHeads);
			
			for(whoseTurn = 0; whoseTurn < (HydraHead.headCount+1); ++whoseTurn){
				System.out.printf("Turn %d\n", whoseTurn);
				try {
					sem.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if(Adventurer.health<=0){
					System.out.println("The adventurer has died!");
					break;
				}
				
				if(whoseTurn == HydraHead.headCount){
					//Adventurer's turn
					
					String availableheads="You may attack: ";
					int aliveCount=0;
					for(int i = 0; i < HydraHead.headCount; ++i){
						if (hydra[i].alive){
							availableheads+=i;
							availableheads+=" ";
							aliveCount++;
						}
						
					}
					if (aliveCount==0)break;
					
					if (Adventurer.ultimateCharge>=3){
						availableheads+=" Or press 100 to activate ultimate attack!";
					}

					System.out.println(availableheads);
					
					System.out.println("Which head to attack?");
					for(int i = 0; i < HydraHead.headCount; ++i){
						
					}
					int attack = input.nextInt();
					if (attack==100 && Adventurer.ultimateCharge>=3 ){
						Adventurer.ultimateCharge=0;
						System.out.println("Using ultimate!");
						int killed=0;
						for(int i = 0; i < HydraHead.headCount; ++i){
							if(killed==10 || HydraHead.livingHeads<=0) break;
							if (hydra[i].alive) {
								hydra[i].alive=false;
								System.out.printf("Thread %d killed!\n", i);
								++killed;
								HydraHead.livingHeads--;
							}
						}
					}
					else{
					while (attack>=HydraHead.headCount){
						System.out.println("That's not a valid head! Try again.");
						attack = input.nextInt();
					}
					if (!hydra[attack].alive){
						System.out.println("That one's already dead! Try again!");
						attack = input.nextInt();
					}
					hydra[attack].takeDamage();
					System.out.printf("Head %d has %d health!\n", attack, hydra[attack].health);
					if(hydra[attack].health<=0){
						whoseTurn++;
						HydraHead.livingHeads--;
						System.out.printf("Head %d killed!\n", attack);
						hydra[attack].stop();
						hydra[attack].alive=false;
						HydraHead.headCount++;
						hydra[HydraHead.headCount].start();
						HydraHead.headCount++;					
						hydra[HydraHead.headCount].start();
						Adventurer.ultimateCharge++;
					}
					
				}
				
				
				
			}
			
				sem.release();
		}
			
		}
		
		System.out.println("You had defeated the Hydra!");

	}
	

	
	public static void attackAdvent(Adventurer advent){
		advent.health--;
	}

}
