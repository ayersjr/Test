package com.csci340.mazjoeproject;

public class Adventurer {
	
	public static String name;
	
	public static int health;
	
	public static int ultimateCharge=0;
	
	public Adventurer(){
		this.name = "Bread";
	}
	
	public Adventurer(String name){
		this.name=name;
	}
	

}
