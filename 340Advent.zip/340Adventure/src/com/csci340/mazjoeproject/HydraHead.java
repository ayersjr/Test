package com.csci340.mazjoeproject;

import java.util.concurrent.Semaphore;

public class HydraHead extends Thread{
	
	public static int headCount;
	public static int livingHeads;
	public int id;
	
	public int health;
	
	public boolean alive;
	
	public HydraHead(int id){
	this.id=id;	
	}
	
	public void run(){
		this.alive=true;
		livingHeads++;
		System.out.printf("A new Hydra head Emerges! The hydra has %d heads!\n", livingHeads);
		headCount++;
		
		this.health = 10;
		
		while (this.health>0 && alive){
			
			if (Main.whoseTurn==this.id){
				
				try {
					Main.sem.acquire();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				Main.sem.release();
				attack();
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		livingHeads--;
		
		}
	
	
	public void attack(){
		System.out.println(this.id + " is attacking adventurer!");
		Adventurer.health--;
		System.out.printf("%s has %d health!\n", Adventurer.name, Adventurer.health);
		
	}
	
	public void takeDamage(){
		this.health-=5;
	}
	
	

}
